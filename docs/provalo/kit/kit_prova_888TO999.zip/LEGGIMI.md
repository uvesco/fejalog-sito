# Kit di prova di Fejalog

Un **gregge inventato** per provare Fejalog con più device, dal progetto fino agli snippet ARVET: i file della BDN,
il pacchetto, i ricercati e le **schede da stampare**, una per capo, divise per tipo (fattispecie). Tutto fittizio:
stabilimento **888TO999 «AZ. AGR. ESEMPIO»**, contrassegni `IT066000000NNN` (e un `FR…`). Lo genera
`Rscript strumenti/genera_kit_prova.R` (dalla radice del repository; usa in sola lettura un altro strumento dell'autore). È la base del
tutorial del sito di Fejalog.

Un **secondo kit**, con cinque stabilimenti di lavoro, registri storici completi, stabilimenti chiusi e i 2/33, sta in
`cinque_stabilimenti/` (il suo `LEGGIMI.md`).

## Che cosa c'è

| File | A che cosa serve |
|---|---|
| `bdn/registri/888TO999_pecore_…txt`, `888TO999_capre_…txt` | registri BDN dello stabilimento di lavoro (presenti e usciti, le causali alfabetiche elencate sotto) |
| `bdn/registri/888TO888_pecore_…txt` | il registro del pascolo condiviso: i suoi capi sono «altro stabilimento» |
| `bdn/contrassegni/888TO999_pecore_contrassegni_…txt`, `…_capre_…` | i contrassegni disponibili (marche mai messe su un capo) |
| `pacchetto_888TO999_kit.json` | lo stesso progetto come pacchetto (in alternativa ai file BDN) |
| `ricercati_888TO999.csv` | quattro capi ricercati (sono anche nel pacchetto; il CSV si carica in campo) |
| `in_corsa/888TO777_pecore_…txt` | il registro del **venditore**: si carica come riferimento; il DDA si dichiara sul singolo prelievo |
| `in_corsa/888TO999_pecore_…_1100.txt` | il registro di 888TO999 **aggiornato**: …010 risulta venduto (V) |
| `schede_kit_prova_888TO999.pdf` (e `.html`) | le schede da stampare (A4, 29 pagine), divise per tipo, ognuna con **cosa deve succedere** |
| `elenco_kit_prova.csv` | ogni scheda: sezione, contrassegno, codice elettronico, anagrafica, cosa deve succedere |

Il gregge: 220 pecore, 12 montoni e 40 capre presenti (2 becchi); 48 pecore uscite, due per ogni codice di uscita della
BDN (W, H, F; D, N, Q, Y; V, E, G, I, J, K, P, R, S, T, U; M, A; C, L, X, Z), e 4 capre uscite; 6 capi del pascolo
condiviso; 15 marche disponibili (10 pecore, 5 capre); 5 capi che non sono in nessun registro; 6 capi del venditore; 2
capre da prelevare come pecore; 1 codice estero; 4 ricercati; 3 doppi. In tutto 359 capi e 362 schede.

## Come si legge una scheda

- **Col lettore**: il barcode è il **codice elettronico come lo manda il lettore di microchip** (`0380` + 12 cifre; il
  francese `0250…`). Un lettore di barcode in modalità tastiera (HID) fa la stessa cosa del lettore Bluetooth: scrive le
  cifre e Invio.
- **A mano**: sul tastierino si digitano le **ultime cifre** del contrassegno (in grassetto sulla scheda).
- Le schede dei **ricercati** hanno il bordo viola: deve comparire il banner viola, con la vibrazione.

## Percorso

1. **Device.** Installare l'APK (cartella Fejalog di Drive) sul tablet della Regia e sui palmari. In ogni device:
   Impostazioni, utente (nome, cognome, codice fiscale) e nome del device.
2. **Progetto (Regia).** Progetto › Nuovo › dai file della BDN: scegliere i cinque file di `bdn/` (anche dentro
   uno zip). Stabilimento di lavoro 888TO999; 888TO888 resta di riferimento. In alternativa: Nuovo › pacchetto e
   `pacchetto_888TO999_kit.json`. Progetto › Registri: la tabella dice quanti capi e contrassegni per stabilimento.
3. **Regole per i problematici.** Smarriti e rubati sono sempre fra i problematici, senza numero preassegnato. La Regia verifica le soluzioni previste per le altre tipologie.
4. **Rete.** Modalità di rete del progetto (Wi-Fi locale o hotspot della Regia); i palmari entrano chiedendo alla
   Regia («Fai entrare»), o col QR la prima volta.
5. **Ricercati.** La Regia carica `ricercati_888TO999.csv` (in campo, anche dopo l'inizio).
6. **Campionamento.** Ci si dividono le pagine delle schede; ogni sezione dice cosa deve succedere. Da provare:
   pecore, montoni (numeri dei maschi in testa) e capre nella loro serie; usciti, altro stabilimento e marche
   disponibili fra i problematici; i capi in nessun registro con «Inserimento forzato» e l'**anagrafica obbligatoria**
   (la razza si sceglie dall'elenco di ARVET, in testa quelle del gregge); le capre «discordanti» cercate fra le pecore;
   il codice estero dal lettore.
7. **Doppi.** Le tre schede dell'ultima sezione sono capi già nel gregge: leggerle da **un altro palmare**. In rete
   compare «DOPPIO CONTRASSEGNO» col nome di chi l'ha già fatto; fuori rete la banda dice «Doppi NON controllati» e il
   doppio si scopre al ritorno della rete.
8. **Registri in corsa (Regia).** Dati › Registri BDN e contrassegni: carica `in_corsa/888TO777_pecore_…` come **altro
   stabilimento di riferimento**. Dichiara **Acquisto con DDA sul singolo prelievo** del venditore: resta problematico.
   La Regia verifica il documento (valido o da rifare); dopo DDA valido, l'operatore o delegato registra l'ingresso
   fuori dall'app. Solo dopo la conferma dell'ingresso registrato si può normalizzare, se non ci sono altre anomalie.
   Il capo successivo non eredita la spunta; il venditore non diventa uno stabilimento di lavoro.
   Poi `in_corsa/888TO999_pecore_…_1100.txt` sostituisce il registro di 888TO999: …010 diventa uscito per vendita, e se
   è già stato prelevato si riclassifica.
9. **Rete difficile.** Spegnere la Wi-Fi di un palmare (barra rossa Wi-Fi persa; ordinari da isolato con etichetta distinta), spegnere la Regia,
   riaccendere: i numeri restano definitivi e le impronte tornano uguali.
10. **Fine lavori.** Soluzione problemi (per tipologia e per provetta), Riordino (la guida a spunta), Import/Export
    (lo zip di fine lavori con gli snippet ARVET, le cose da fare per l'allevatore, i report).
11. **ARVET.** Gli snippet del kit **non vanno incollati nell'ARVET vero**: i contrassegni sono inventati e lo snippet
    2.0 **scrive** in ARVET i capi che non sono nell'elenco. Per vederlo al lavoro senza scrivere niente, in console si
    scrive prima `window.__ARVET_PROVA__=true;` e poi si incolla lo snippet: fa Cerca e prepara i campi, ma non preme
    Conferma.

## Anomalie: lista di controllo senza sito

I numeri brevi qui sotto sono i suffissi di `IT066000000NNN`. Copia sempre l'etichetta mostrata dall'app: le immagini
e alcuni esempi stampati usano forme precedenti. Per una problematica scrivi anche il contrassegno completo.

| Prova | Schede / azione | Esito atteso |
|---|---|---|
| ☐ Smarrito, rubato, furto/smarrimento | 401 (W), 403 (H), 405 (F); capre 449 e 450 | Sempre problematici senza numero ordinario. Il ritrovamento fisico non cambia la BDN. |
| ☐ Morto, abbattuto, presunto morto | 407–414; prova tutte le causali | Uscito da verificare anche se sul campo è vivo; problematica. |
| ☐ Trasferiti, macello, altre causali | 415–436, 437–440, 441–448 | Prova ciascuna causale: data e motivo leggibili, nessuna ordinaria automatica. |
| ☐ Altro stabilimento non campionato | 501–506 di 888TO888 | Avviso viola; Scarta non registra, Inserisci e conferma produce una problematica. Il registro caricato non significa risanamento contemporaneo. |
| ☐ Marca non registrata su un capo | 601–610 e 651–655 | Blu; sesso, razza e nascita obbligatori; problematica. |
| ☐ Codice in nessun registro caricato | 701–705 | Forzato col contrassegno completo e anagrafica obbligatoria. Verificare anche la completezza degli input. |
| ☐ Nascita oltre sei mesi | Su marca disponibile o forzato | Avviso giallo non bloccante; non è il controllo della soglia diagnostica. |
| ☐ DDA individuale | 801, poi 802, dopo il caricamento del venditore | Solo 801 dichiarato; verifica valido/da rifare, poi ingresso registrato prima di normalizzare. |
| ☐ Specie discordante | 341–342 nella pagina Pecore | Verificare animale e specie; confermando la discordanza resta problematica. |
| ☐ Doppio noto e scoperto al rientro | Seconde schede 003, 150, 225 | Già fatto non registra; Preleva come doppio crea un distinto campione problematico. Verificare le collisioni fisiche se richiesto. |
| ☐ Senza contrassegno | Simula un presente senza marche prima di averlo prelevato | Scelta per sesso/razza/età, identificazione attribuita, DX/SX da sostituire. Se poi viene prelevato il capo con le marche, l'attribuita va verificata a fine lavori. |
| ☐ Orecchini, bolo e sesso | Su un presente ordinario | Spunte e sesso corretto conservati; DX o bolo indicano senza transponder, senza rendere problematica da soli la provetta. |
| ☐ Diventata problematica | Preleva 010, poi carica il registro aggiornato `_1100` | Ora risulta venduta; etichetta conservata, soluzione e spostamento guidati a fine lavori. |
| ☐ Ora in lista | Completa la verifica DDA e conferma l'ingresso registrato | Normalizzazione disponibile se non restano altre anomalie. |
| ☐ Persa, ripetuta, ritrovata | Segna Persa su un campione, ripeti, poi Ritrovata | Numero precedente impegnato; dopo il ritrovamento due validi da risolvere come doppio. |
| ☐ Ricercati | 005, 017, 222, 703 | Banner con azione, anche sul forzato 703. Non sono necessariamente problematici. |
| ☐ Accantonata e conferma mancata | Accantona una prova; su un'altra scrivi l'etichetta ma non confermare | Risolvere accantonata con Cerca e registra/Scarta. Per la tardiva, solo Regia a campionamento chiuso, con provetta fisica, etichetta verificata e nota. |
| ☐ Annullata ed eliminata | Prova annullo su un campione ed Eliminata su un altro | Storia conservata, campioni da mettere da parte senza numero finale né ARVET; etichetta annullata non riutilizzabile. |
| ☐ Codice estero e ordinaria da isolato | FR066000000950; un adulto senza rete | Non sono di per sé anomalie anagrafiche. Al rientro verificare i doppi; la scritta resta invariata. |

**Fuori età, stabilimenti chiusi e confronto fra più stabilimenti di lavoro:** usa il kit separato a cinque
stabilimenti e la sua lista nel LEGGIMI. Il kit singolo non contiene una sezione di giovani sotto soglia.

**Prima del riordino:** controlla regole ed eccezioni individuali; non tutti i problematici vanno nell'invio.
Le eliminate non hanno numero finale né ARVET. Il prelievo non corregge la BDN. Le attribuite con successiva comparsa
del capo con le marche restano una simulazione, non una prova sul campo già eseguita.

## Rigenerare

`Rscript strumenti/genera_kit_prova.R [cartella dello strumento]`: stessi capi a ogni giro (seme fisso). `KitProvaTest`
(`./gradlew :shared:jvmTest`) controlla che il pacchetto sia valido e che l'importazione dei file BDN dia lo stesso
pacchetto.

## Backup di esempio e download del sito

`backup_esempio_888TO999.zip` contiene pochi campioni registrati e posati, una problematica e campionamento chiuso. È generato dal pacchetto di questo kit con le API dell’app (`KitBackupEsempioTest`). Dalla radice, con JDK 21 e Android SDK: `strumenti/pacchetti_sito_kit.sh` rigenera entrambi i backup e gli archivi del sito. La verifica esclude i dati reali con `-PsoloFixture=true`. Nessun codice fiscale reale nei profili di prova.
