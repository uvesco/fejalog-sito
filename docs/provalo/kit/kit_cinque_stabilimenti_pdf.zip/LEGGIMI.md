# Kit di prova a cinque stabilimenti

È il secondo kit di prova di Fejalog (2026-10-24): cinque stabilimenti di lavoro nello stesso progetto, con i registri
storici completi. Tutto è inventato: codici `888TO…`, denominazioni «AZ. AGR. ESEMPIO…», contrassegni
`IT0660000NNNNN` (da 10001 in su), diversi da quelli del primo kit.

Le frequenze vengono dai registri veri di due greggi in `_staging/`, riportate solo come numeri aggregati:
- **motivi di uscita degli ovini**: vendita o trasferimento (V) 74%, macello (M) 9%, smarrimento (W) 8%, morte in
  stabilimento (D) 5%, furto o smarrimento (F) 2,5%;
- **furti (H)**: nei registri veri non c'erano, sono aggiunti all'1% su richiesta;
- **usciti per ogni presente**: 1,5;
- **maschi fra i presenti**: 2% negli ovini, 10% nelle capre;
- **età dei presenti**: 18% fra 6 e 12 mesi;
- **razze e anni d'uscita**: anche queste dai due greggi.

Lo genera `Rscript strumenti/genera_kit_cinque_stabilimenti.R`, dalla radice del repository, con seme fisso.
`KitProvaTest` controlla due cose:
- importando i file BDN, Fejalog crea lo stesso pacchetto di svet-tools;
- i numeri dei 2/33 sono quelli che assegna l'app.

## Gli stabilimenti

| Codice | Ruolo | Lettera | Ovini | Capre | Usciti nel registro |
|---|---|---|---|---|---|
| 888TO999 | principale | nessuna | 500 | 100 | 902 |
| 888TO888 | secondario | X | 120 | 24 | 216 |
| 888TO777 | secondario | Y | 80 | 16 | 144 |
| 888TO666 | secondario | W | 60 | 12 | 108 |
| 888TO555 | secondario | V | 40 | nessuna | 60 |
| 888TO444 | chiuso il 30/06/2025 | | | | 160 |
| 888TO333 | chiuso il 15/11/2023 | | | | 60 |
| 888TO222 | riferimento (pascolo confinante) | | 8 | | 6 |

- **Lettera di specie predefinita**: C sulle capre. Così le etichette sono `12` e `C12` nel principale, `X12` e `XC12`
  nel secondario X, e così via.
- **Chiusi**: una parte delle loro vendite è finita negli stabilimenti di lavoro. Sono capi presenti oggi, con la loro
  storia nel registro del chiuso.
- **Fra 888TO999 e 888TO888**: due pecore risultano uscite (V) dal primo e presenti nel secondo.
- **In corsa**: `in_corsa/888TO888_pecore_…_1100.txt` è il registro di 888TO888 aggiornato, con un capo venduto dopo lo
  scarico.
- **Marche disponibili**: in cinque stabilimenti.
- **Ricercati**: uno per stabilimento, in `ricercati_cinque_stabilimenti.csv`.
- **Doppi**: uno per stabilimento.
- **Capi in nessun registro**: quattro.

## Che cosa c'è

| File | A che cosa serve |
|---|---|
| `bdn/registri/` (14 file), `bdn/contrassegni/` (7) | i file della BDN per Nuovo › file BDN (si possono scegliere tutti insieme, anche in uno zip) |
| `pacchetto_888TO999_cinque_stabilimenti.json` | lo stesso progetto come pacchetto, come lo fa svet-tools |
| `schede_kit_cinque_stabilimenti.pdf` (e `.html`) | 2576 schede col barcode del codice elettronico, 180 pagine. Per ogni stabilimento prima i presenti (pecore, montoni, capre, giovani), poi un capitolo per ogni motivo d'uscita; in fondo marche, capi in nessun registro e doppi. Ogni sezione dice cosa deve succedere |
| `elenco_kit_cinque_stabilimenti.csv` | ogni scheda: sezione, contrassegno, codice elettronico, anagrafica, cosa deve succedere (per filtrare e stampare solo una parte) |
| `2-33/ingresso/` | i 2/33 come li stampa ARVET, uno per stabilimento e specie (9 file `.htm`): sono quelli da dare all'app |
| `2-33/con_provette/` | il risultato atteso (`.html` e `.pdf`): lo stesso 2/33 precompilato, con l'età diagnostica di 12 mesi. Stesso ordine di ARVET, il numero nella colonna «Provetta», negli ovini la riga dei maschi grigia; i fuori età restano senza numero |
| `prima_del_campo/provette_contrassegni_12mesi_A3.pdf` (e `.html`) | il foglio A3 orizzontale atteso, Provetta \| Contrassegno: i numeri assegnati con 12 mesi in ordine di provetta, serie per serie, maschi degli ovini in grigio (due fogli). prodotto fra le stampe pre-campo |
| `2-33/numerazione_attesa_12mesi.csv` | i 796 numeri assegnati che l'app deve dare con 12 mesi e la C sulle capre |

## I 2/33

- **Il 2/33 precompilato si produce in configurazione**, fra le stampe pre-campo, partendo dai file fittizi di ingresso. I file con le provette sono esempi del risultato iniziale a 12 mesi. Il sito produce anche il 2/33 finale a partire dal backup campionato, in Uscite, caricando i modelli fittizi di ingresso.
- **Sono fatti sullo schema dei 2/33 ovicaprini veri** della prova del 22 ottobre (solo la struttura, nessun dato):
  - testata della bonifica col codice dello stabilimento e il suo codice a barre;
  - proprietari e detentori; 888TO999 ne ha due, e una parte delle sue capre è del secondo;
  - tabella dei capi a pagine di 40 righe, coi soli presenti in ordine di contrassegno;
  - la colonna «Provetta» vuota;
  - la razza con la sigla di ARVET (BLS, MTT, TCL; nei registri BDN BIE, MET, TAC);
  - il genotipo scrapie dei montoni;
  - in coda righe vuote numerate, il 10% dei capi più 3.
- **I maschi sono sparsi** nell'ordine di contrassegno, come nei 2/33 veri: i numeri della colonna «Provetta» non
  seguono l'ordine delle righe (fra le pecore i maschi hanno i primi numeri).
- Il lettore di svet-tools (`R/fabbisogno_tubercolina.R`) legge questi file come quelli veri.

## Percorso

1. **Progetto (Regia).** Progetto › Nuovo › dai file della BDN, con tutti i file di `bdn/`.
   - Stabilimenti di lavoro: 888TO999, 888TO888, 888TO777, 888TO666, 888TO555. 888TO222 e i due chiusi restano di
     riferimento.
   - Età diagnostica: 12 mesi per confrontare i numeri con `2-33/con_provette/` (con 6 mesi entrano anche i giovani).
   - Lettera di specie predefinita.
2. **Controllo dei numeri.** La tabella della numerazione (CSV) deve coincidere con `2-33/numerazione_attesa_12mesi.csv`.
3. **Ricercati e rete.** Si carica `ricercati_cinque_stabilimenti.csv`; i palmari entrano come sempre.
4. **Campionamento.** Ci si dividono i capitoli delle schede, che dicono cosa deve succedere.
   - Con tre cifre compaiono spesso capi di stabilimenti diversi; con quattro, uno solo.
   - I giovani fra 6 e 12 mesi hanno il numero ordinario con soglia 6 mesi; con soglia 12 mesi, se prelevati,
     sono problematici ed eliminati per impostazione predefinita. Le età delle schede sono riferite al 24/10/2026.
   - Gli usciti sono tutti fra i problematici: smarriti e rubati sempre, anche ritrovati.
   - Se un capo risulta solo uscito da un chiuso, verificarne l'ingresso; se invece è già presente in uno
     stabilimento di lavoro, la vecchia uscita è storia e non basta a renderlo problematico.
5. **Altro stabilimento e aggiunta in corsa.** I capi di 888TO222 compaiono viola, fra i problematici. Poi la Regia
   aggiunge 888TO222 come stabilimento secondario (Stabilimenti e lettere) e si annota cosa succede ai capi già
   prelevati e a quelli nuovi.
6. **Registro in corsa.** `in_corsa/888TO888_pecore_…_1100.txt` sostituisce il registro di 888TO888: il capo venduto
   diventa uscito e, se è già prelevato, si riclassifica.
7. **Fine lavori**, come nel primo kit: Problemi da risolvere, Non trovati e tardive, Riordino, Snippet ed
   esportazioni, e gli strumenti del sito.
8. **ARVET.** Gli snippet del kit non vanno incollati nell'ARVET vero. Per vederli al lavoro, in console prima
   `window.__ARVET_PROVA__=true;` (`docs/agenti/procedure.md`).

## Anomalie: lista di controllo senza sito

Usa data della seduta **24/10/2026**, soglia **12 mesi**, e copia le etichette effettive della conferma.
I giovani delle schede restano giovani alla data del kit, non a qualunque data successiva.

| Prova | Schede / azione | Esito atteso |
|---|---|---|
| ☐ Usciti ritrovati | Per ogni stabilimento, capitoli W, H, F, V, M, D, Y dove presenti | Smarriti e rubati sempre problematici; controlla identità, data e causale anche per morti, macello e trasferiti. |
| ☐ Fuori età | IT066000010007 (11/12/2025), più una scheda sotto sei mesi | Con soglia 12 mesi sono problematici se prelevati, senza numero ordinario; predefinita Eliminata, niente numero finale né ARVET. Confronta i 2/33 iniziali senza numero. |
| ☐ Secondario già campionato | Un adulto presente di 888TO888 | Ordinario nella serie dello stabilimento di lavoro, distinta da quella del principale. |
| ☐ Stabilimento non campionato | Un presente di 888TO222 prima di aggiungerlo | Avviso viola, problematico; il solo registro non lo include nella profilassi. |
| ☐ Nuovo secondario | Aggiungi 888TO222 solo per simularne il risanamento contemporaneo; poi preleva un altro adulto | Nuovi capi nella sua serie; scritte già emesse invariate, da controllare prima del riordino. |
| ☐ Stabilimento chiuso | Capi solo usciti di 888TO444/888TO333, poi un capo già presente in uno di lavoro con vecchia uscita dal chiuso | Il primo richiede verifica di provenienza/ingresso; il secondo non è problematico per la sola storia, perché prevale il presente. |
| ☐ Trasferimento fra due di lavoro | Sezione «888TO888 · arrivate da 888TO999» | Presente in 888TO888, serie X; la precedente uscita da 888TO999 non lo duplica. |
| ☐ Marche e forzati | Sezioni Marche disponibili / In nessun registro | Sesso, razza, nascita obbligatori; per il forzato codice completo e destinazione verificata. Una nascita oltre sei mesi genera un avviso non bloccante. |
| ☐ Registro aggiornato | Preleva prima il capo poi venduto nel file `in_corsa/888TO888_pecore_…_1100.txt`, quindi carica quel file | Diventata problematica; scritta fisica e assegnazione iniziale conservate, soluzione guidata. |
| ☐ Ricercati e doppi | Ricercati del CSV; seconde schede da un altro palmare, anche dopo isolamento | Banner con azione; Già fatto non registra, la conferma come doppio crea una distinta problematica. Al rientro verifica tutte le provette coinvolte. |
| ☐ Senza marche, orecchini/bolo e sesso | Simula un presente non prelevato senza identificativi; prova anche le spunte e il sesso corretto su altre schede | Attribuzione per anagrafica tracciata, DX/SX da sostituire; se poi arriva il prelievo col contrassegno letto, l'attribuita va verificata. DX o bolo segnalati alimentano i senza transponder. |
| ☐ Perdite, accantonate e tardive | Persa → ripeti → Ritrovata; Accantona; provetta scritta e non confermata | Doppio dopo il ritrovamento; accantonata da registrare/scartare; tardiva solo dalla Regia a campionamento chiuso con etichetta verificata e nota. |

Per il **DDA individuale**, la **specie discordante**, il **codice estero** e tutte le causali alfabetiche del kit
singolo usa anche l'altro archivio di prova `kit_prova_888TO999.zip` e la sua lista nel LEGGIMI. Il DDA non è un ruolo
da applicare all'intero venditore: si dichiara per singolo prelievo, poi documento valido/da rifare e ingresso registrato
prima della normalizzazione. Fejalog non scrive nella BDN.

Controlla le soluzioni prima del riordino: in coda, eliminata oppure normalizzata quando ammessa. Le eliminate vanno
messe da parte. Queste sono prove da eseguire e annotare, non certificazioni di esecuzione su dispositivi fisici.

## Backup di esempio e download del sito

`backup_esempio_cinque_stabilimenti.zip` deriva dal pacchetto di questo kit, con le API dell’app: pochi campioni in tutte le serie non vuote, una problematica, pose complete e campionamento chiuso. Dalla radice, con JDK 21 e Android SDK: `strumenti/pacchetti_sito_kit.sh`. I 2/33 di `ingresso/` riproducono solo la struttura ARVET e contengono dati inventati, compresi i codici fiscali numerici `888000…`.
